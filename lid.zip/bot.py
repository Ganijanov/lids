import telebot

bot = telebot.TeleBot("7103426824:AAHYGRa3bfg3oID7mZVDW09ny_LaPo7Lszg", parse_mode=None)

bot.infinity_polling()
